import os
import json
import tempfile
import urllib.parse
from pathlib import Path
from flask import Flask, request, jsonify

# External packages
import requests
import trafilatura
import gspread
import bs4
from google.oauth2.service_account import Credentials
from openai import OpenAI
from google.cloud import texttospeech
from moviepy.editor import *
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials as OAuthCreds

# ----------------------------------------------------------------------------
# 環境変数 & 定数
# ----------------------------------------------------------------------------
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
SHEET_URL = os.environ.get("SHEET_URL")  # 例: https://docs.google.com/...
DRIVE_FOLDER_ID = os.environ.get("DRIVE_FOLDER_ID")  # 共有ドライブ内のフォルダID
# Secret Manager で以下を注入: GCP_SA_JSON_SECRET, YOUTUBE_TOKEN_JSON

SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive",
    "https://www.googleapis.com/auth/cloud-platform",
]

app = Flask(__name__)
client = OpenAI(api_key=OPENAI_API_KEY)

# ----------------------------------------------------------------------------
# 認証ヘルパ
# ----------------------------------------------------------------------------

def get_service_account_creds():
    """Secret Manager から取得したサービスアカウントJSONをCredentialsへ"""
    sa_json = os.environ.get("GCP_SA_JSON_SECRET")
    if not sa_json:
        raise RuntimeError("環境変数 GCP_SA_JSON_SECRET が未設定です")
    info = json.loads(sa_json)
    return Credentials.from_service_account_info(info, scopes=SCOPES)


def get_youtube_creds():
    """token.json 相当を環境変数からロードし、必要なら refresh"""
    token_json = os.environ.get("YOUTUBE_TOKEN_JSON")
    if not token_json:
        raise RuntimeError("環境変数 YOUTUBE_TOKEN_JSON が未設定です")
    token_path = "/tmp/token.json"
    with open(token_path, "w", encoding="utf-8") as fp:
        fp.write(token_json)
    creds = OAuthCreds.from_authorized_user_file(token_path)
    if creds.expired and creds.refresh_token:
        creds.refresh(Request())
    return creds

# ----------------------------------------------------------------------------
# Google Sheets Access
# ----------------------------------------------------------------------------

def get_sheet():
    creds = get_service_account_creds()
    gc = gspread.authorize(creds)
    return gc.open_by_url(SHEET_URL).sheet1

# ----------------------------------------------------------------------------
# 1) 記事取得
# ----------------------------------------------------------------------------

def fetch_article(url: str) -> str:
    text_parts, visited = [], set()
    while url and url not in visited:
        visited.add(url)
        resp = requests.get(url, timeout=15)
        article_text = trafilatura.extract(resp.text, favor_recall=True)
        if article_text:
            text_parts.append(article_text)
        soup = bs4.BeautifulSoup(resp.text, "lxml")
        next_link = soup.find("link", rel="next")
        url = urllib.parse.urljoin(url, next_link["href"]) if next_link else None
    return "\n\n".join(text_parts).strip()

# ----------------------------------------------------------------------------
# 2) 画像生成 (GPT-4o + DALL·E3)
# ----------------------------------------------------------------------------

def generate_images(article: str, n: int = 3):
    prompt = (
        "以下の記事内容を読んで、ニュース動画用の背景シーン説明を" f"{n}個、日本語で1行ずつ出力してください。"
    )
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt + "\n\n" + article[:4000]}],
    )
    scenes = [l.strip() for l in resp.choices[0].message.content.splitlines() if l.strip()]
    paths = []
    for i, scene in enumerate(scenes[:n]):
        img_resp = client.images.generate(
            model="dall-e-3",
            prompt=scene,
            size="1024x1024",
        )
        url = img_resp.data[0].url
        raw = requests.get(url).content
        path = f"/tmp/scene_{i}.png"
        with open(path, "wb") as fp:
            fp.write(raw)
        paths.append(path)
    return paths

# ----------------------------------------------------------------------------
# 3) 読み上げ原稿生成
# ----------------------------------------------------------------------------

def create_narration(article: str) -> str:
    prompt = (
        "次のニュース記事本文を、自然な日本語の朗読原稿に整形してください。\n"
        "・見出し行の後に改行で間を取る\n"
        "・不自然な表現は口語に言い換える\n"
        "・全体で3分以内に収まるよう要約も可\n\n記事:\n" + article[:8000]
    )
    res = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
    )
    return res.choices[0].message.content.strip()

# ----------------------------------------------------------------------------
# 4) 音声合成 (Google TTS)
# ----------------------------------------------------------------------------

def synthesize_speech(text: str) -> str:
    creds = get_service_account_creds()
    tts = texttospeech.TextToSpeechClient(credentials=creds)
    input_text = texttospeech.SynthesisInput(text=text)
    voice = texttospeech.VoiceSelectionParams(
        language_code="ja-JP", name="ja-JP-Standard-B"
    )
    audio_cfg = texttospeech.AudioConfig(
        audio_encoding=texttospeech.AudioEncoding.MP3,
        speaking_rate=1.05,
    )
    audio = tts.synthesize_speech(input_text, voice, audio_cfg)
    out_path = "/tmp/voice.mp3"
    with open(out_path, "wb") as fp:
        fp.write(audio.audio_content)
    return out_path

# ----------------------------------------------------------------------------
# 5) 動画生成 (moviepy)
# ----------------------------------------------------------------------------

def make_video(images: list[str], voice_path: str) -> str:
    audio_clip = AudioFileClip(voice_path)
    duration = audio_clip.duration
    img_duration = duration / len(images)
    clips = [ImageClip(p).set_duration(img_duration) for p in images]
    video = concatenate_videoclips(clips, method="compose").set_audio(audio_clip)
    out_path = "/tmp/news_video.mp4"
    video.write_videofile(out_path, codec="libx264", audio_codec="aac", fps=30)
    return out_path

# ----------------------------------------------------------------------------
# 6) Google Drive アップロード
# ----------------------------------------------------------------------------

def upload_drive(file_path: str) -> str:
    creds = get_service_account_creds()
    drive = build("drive", "v3", credentials=creds)
    meta = {"name": Path(file_path).name, "parents": [DRIVE_FOLDER_ID]}
    media = MediaFileUpload(file_path, mimetype="video/mp4", resumable=True)
    file = drive.files().create(body=meta, media_body=media, fields="id").execute()
    # 公開リンク作成
    drive.permissions().create(fileId=file["id"], body={"role": "reader", "type": "anyone"}).execute()
    return f"https://drive.google.com/file/d/{file['id']}/view"

# ----------------------------------------------------------------------------
# 7) YouTube アップロード
# ----------------------------------------------------------------------------

def upload_youtube(file_path: str, title: str) -> str:
    yt_creds = get_youtube_creds()
    yt = build("youtube", "v3", credentials=yt_creds)
    body = {
        "snippet": {
            "title": title,
            "description": title,
            "categoryId": "25",
        },
        "status": {"privacyStatus": "public"},
    }
    media = MediaFileUpload(file_path, resumable=True, mimetype="video/mp4")
    req = yt.videos().insert(part="snippet,status", body=body, media_body=media)
    resp = req.execute()
    return f"https://youtu.be/{resp['id']}"

# ----------------------------------------------------------------------------
# 8) スプレッドシート更新
# ----------------------------------------------------------------------------

def update_sheet(row: int, drive_url: str, yt_url: str):
    sheet = get_sheet()
    if drive_url:
        sheet.update(f"B{row}", drive_url)
    if yt_url:
        sheet.update(f"C{row}", yt_url)

# ----------------------------------------------------------------------------
# メイン処理関数
# ----------------------------------------------------------------------------

def process_row(row: int, url: str):
    article = fetch_article(url)
    images = generate_images(article)
    script = create_narration(article)
    voice = synthesize_speech(script)
    video = make_video(images, voice)
    drive_url = upload_drive(video)
    yt_url = upload_youtube(video, script.split("\n")[0][:50])
    update_sheet(row, drive_url, yt_url)
    return {"row": row, "drive": drive_url, "yt": yt_url}

# ----------------------------------------------------------------------------
# Flask ルーティング
# ----------------------------------------------------------------------------

@app.route("/health")
def health():
    return jsonify({"status": "ok"})


@app.route("/process", methods=["POST"])
def process():
    results = []
    sheet = get_sheet()
    rows = sheet.get_all_values()[1:]  # ヘッダー除外
    for idx, r in enumerate(rows, start=2):
        url = r[0] if len(r) else ""
        done = r[1] if len(r) > 1 else ""
        if url and not done:
            try:
                res = process_row(idx, url)
                res["status"] = "success"
                results.append(res)
            except Exception as e:
                sheet.update(f"D{idx}", str(e))
                results.append({"row": idx, "error": str(e)})
    return jsonify(results)

# ----------------------------------------------------------------------------
if __name__ == "__main__":
    # ローカルテスト用
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
