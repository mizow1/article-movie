# ニュース記事自動動画生成パイプライン

Google スプレッドシートに登録したニュース記事 URL から、背景画像・音声付きニュース動画を自動生成し、Google Drive と YouTube へ公開するパイプラインです。

## 機能概要
1. **URL 取得** — Google Sheets の A 列から未処理 URL を取得。
2. **記事解析** — HTML を取得し `trafilatura` で本文抽出。ページネーション (`<link rel="next">`) にも対応。
3. **画像生成** — GPT-4o でシーン説明を作成し、DALL·E 3 で最大 3 枚生成。
4. **原稿作成** — GPT-4o で自然な朗読台本を生成。
5. **音声合成** — Google Cloud Text-to-Speech で MP3 生成。
6. **動画生成** — `moviepy` で画像+音声を連結し MP4 生成。
7. **公開** — Google Drive にアップロード（共有リンク生成）→ YouTube に同時アップロード。
8. **結果書込** — Drive URL を B 列、YouTube URL を C 列に書き込み。エラーは D 列へ。

## ディレクトリ構成
```
article-movie2/
├── app.py              # Cloud Run 用 Flask アプリ
├── requirements.txt    # Python 依存ライブラリ
├── Dockerfile          # Cloud Run コンテナ定義
├── README.md           # このファイル
└── .gitignore          # 機密ファイルを除外
```

## 必要な API と認証情報
| サービス | 用途 | 認証方法 |
|----------|------|----------|
| Google Sheets API | URL 取得・書込 | サービスアカウント JSON |
| Google Drive API  | 動画アップロード | 同上 |
| YouTube Data API v3 | 動画アップロード | OAuth 2.0 `token.json` |
| Google Cloud Text-to-Speech | 音声合成 | サービスアカウント JSON |
| OpenAI API | GPT-4o, DALL·E 3 | `OPENAI_API_KEY` |

### Secret Manager に登録するキー
| 名前 | 値 |
|------|----|
| `OPENAI_API_KEY` | `sk-xxxxxxxx` |
| `GCP_SA_JSON_SECRET` | サービスアカウント JSON 本文 |
| `YOUTUBE_TOKEN_JSON` | `token.json` 本文 |

## 必須環境変数
| 変数 | 例 | 説明 |
|------|----|------|
| `SHEET_URL` | `https://docs.google.com/...` | 対象スプレッドシート URL |
| `DRIVE_FOLDER_ID` | `1IhEHRgt6xIf...` | アップロード先フォルダ ID |
| `OPENAI_API_KEY` | (Secret Manager 参照) | OpenAI キー |
| `GCP_SA_JSON_SECRET` | (Secret Manager) | サービスアカウント |
| `YOUTUBE_TOKEN_JSON` | (Secret Manager) | YouTube token.json |

## デプロイ手順 (Cloud Run)
```bash
# 1. GCP プロジェクト切替
$ gcloud config set project <PROJECT_ID>

# 2. 必要 API 有効化
$ gcloud services enable run.googleapis.com cloudbuild.googleapis.com \
    secretmanager.googleapis.com sheets.googleapis.com drive.googleapis.com \
    youtube.googleapis.com texttospeech.googleapis.com

# 3. Secret Manager 登録 (例)
$ echo "sk-xxxx" | gcloud secrets create OPENAI_API_KEY --data-file=-
$ gcloud secrets create GCP_SA_JSON_SECRET --data-file=./article-movie-44205045b843.json
$ gcloud secrets create YOUTUBE_TOKEN_JSON --data-file=./token.json

# 4. デプロイ
$ gcloud run deploy news-video-generator \
  --source . \
  --region asia-northeast1 \
  --allow-unauthenticated \
  --memory 4Gi --cpu 2 --timeout 3600 \
  --set-env-vars SHEET_URL="https://docs.google.com/...",DRIVE_FOLDER_ID="<FOLDER_ID>" \
  --set-env-vars OPENAI_API_KEY="projects/$(gcloud config get-value project)/secrets/OPENAI_API_KEY:latest" \
  --set-env-vars GCP_SA_JSON_SECRET="projects/$(gcloud config get-value project)/secrets/GCP_SA_JSON_SECRET:latest" \
  --set-env-vars YOUTUBE_TOKEN_JSON="projects/$(gcloud config get-value project)/secrets/YOUTUBE_TOKEN_JSON:latest"

# 5. Cloud Scheduler
$ gcloud scheduler jobs create http news-processor \
  --schedule="0 */6 * * *" \
  --uri="https://<SERVICE_URL>/process" \
  --http-method=POST
```

## ローカルテスト
```bash
# 依存インストール
pip install -r requirements.txt

# 環境変数 .env に設定して実行
flask --app app.py run --port 8080
```

---
© 2025 自動ニュース動画生成プロジェクト
